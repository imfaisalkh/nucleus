<?php

#-----------------------------------------------------------------#
#
#	Here define all the custom functions for the child theme.
#	Please be extremely cautious editing this file,
#	When things go wrong, they intend to go wrong in a big way.
#	You have been warned!
#
#-----------------------------------------------------------------#


#-----------------------------------------------------------------#
# Custom Functions Starts from Here
#-----------------------------------------------------------------#