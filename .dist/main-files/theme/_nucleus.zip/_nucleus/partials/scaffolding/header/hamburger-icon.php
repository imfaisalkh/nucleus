<span class="element menu-icon" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <a href="#">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
    </a>
</span>