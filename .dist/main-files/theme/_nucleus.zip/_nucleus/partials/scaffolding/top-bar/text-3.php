<div class="text-block text-block-3 element" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <?php echo get_theme_mod('nucleus_header_top_bar_text_block_3'); ?>
</div>