<?php get_header(); ?>

	<!-- Main Content -->
	<div id="main-content">

		<?php get_template_part( 'partials/scaffolding/page-header' ); ?>

		<!-- Page Content -->
		<div id="page-content" class="full-width">

			<section class="blog-minimal" data-load-trigger="<?php echo get_theme_mod('nucleus_blog_infinite_scroll', 'button'); ?>">

				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'partials/blog/primary-loop' ); ?>
				<?php endwhile; else: ?>
					<?php get_template_part( 'content', 'none' ); ?>
				<?php endif; ?>

			</section>

			<?php include(locate_template( 'partials/scaffolding/load-more.php' )); ?>

		</div>

	</div>
		
<?php get_footer(); ?>