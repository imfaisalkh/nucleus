<?php


#-------------------------------------------------------------------------------#
#  Filter Body Classes
#-------------------------------------------------------------------------------#


	if ( !function_exists('nucleus_body_class') ) {

		function nucleus_body_class( $classes ) {

			// get values defined in 'globals.inc.php'
		    $is_site_preloader = get_theme_mod('nucleus_site_preloader') ? ' site-preloader-disabled' : '';
		    $menu_type = get_theme_mod('nucleus_menu_type', 'traditional');

			// add custom classes to the $classes array
			$classes[] = $is_site_preloader .' '. $menu_type . '-menu ';

			// return the $classes array
			return $classes;
		}

	}

	add_filter( 'body_class', 'nucleus_body_class' );


#-------------------------------------------------------------------------------#
#  Filter Post Classes
#-------------------------------------------------------------------------------#


	if ( !function_exists('nucleus_post_class') ) {

		function nucleus_post_class( $classes ) {

			$classes[] = '';

			// If 'portfolio' Custom Post Type 
			if ( get_post_type() == "portfolio" ) {

				$folio_cats_slug 	= implode(' ', nucleus_get_term_fields('portfolio_category', 'slug'));

				// add custom classes to the $classes array
				$classes[] = $folio_cats_slug;

			}

			// return the $classes array
			return $classes;
		}

	}

	add_filter( 'post_class', 'nucleus_post_class' );

