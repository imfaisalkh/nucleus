/*-----------------------------------------------------------------------------------

	Custom JS - All front-end jQuery
 
-----------------------------------------------------------------------------------*/

(function( $ ) {

	'use strict';

	/** GENERALS */
	/** ================================================== */

	/** Viewport dimensions */
	var ww = $(window).width();
	var wh = $(window).height();


	/** TEMPLATE FUNCTIONS */
	/** ================================================== */

	var templateFunctions = {


		/** Scroll Position */
		scrollPosition: function() {

			// $('#main-menu > li').on( 'mouseenter' , function(e) {
			// 	$('#main-menu > li.current-menu-item > a').addClass('passive-link');
			// });
			// $('#main-menu > li').on( 'mouseleave' , function(e) {
			// 	$('#main-menu > li.current-menu-item > a').removeClass('passive-link');
			// });


			$('#main-menu > li.current-menu-item > a')
			$('#main-menu > li.current-menu-item > a')


			// initial postion on page load
			$(document).ready(function(){
				$(this).scrollTop(0);
			});

			// scroll indicator click handler
			$('#page-header .scroll-indicator > a').smoothScroll();

			// go to top click handler
			$('#page-controls .page-control.go-top').smoothScroll({
				offset: -150,
				speed: 600
			});

		},

		/** Site Notification */
		siteNotification: function() {

			// initial postion on page load
			$('#page-controls .page-control.notification, a[href^="#trigger-notification"]').on( 'click' , function(e) {
				e.preventDefault();
				$('#site-notification').addClass('animate-in');
			});

			// initial postion on page load
			$('#site-notification .close').on( 'click' , function(e) {
				e.preventDefault();
				$('#site-notification').removeClass('animate-in');
			});

		},

		/** Site Preloader */
		sitePreloader: function() {

			$('.preloader').fadeOut();

		},

		/** Site Menu */
		siteMenu: function() {

            $('ul.sf-menu').superfish({
                animation: { opacity: 'show', top: "220%" },
                animationOut: {opacity:'hide', top: "260%" },
                speed: 'fast',
                delay: 600,
            });

		},

        /** Lightbox */
        lightBox: function() {

            $('.portfolio-grid .portfolio > a[rel="lightbox"], .elementor-image a').fancybox({
                padding : 0,
                helpers : {
                    title   : {
                        type: 'inside'
                    },
                    thumbs  : {
                        width   : 65,
                        height  : 65
                    },
                    media : {}
                },
                beforeLoad: function() {
                    this.title = $(this.element).data('caption');
                }
            });

        },


		/** Site Overlay */
		siteOverlay: function() {

                //horizontal swipe menu
                var init = {

                    openModal: function(type){
                    	if ( type == 'search' ) {
                        	$('#search-filter, #search-filter .widget-wrap').addClass('animate-in');
                    	} else if ( type == 'menu' ) {
							$('#mobile-menu, #mobile-menu .sf-menu').addClass('animate-in');
                    	}
                    },

                    closeModal: function(){
                    	$('#search-filter, #search-filter .widget-wrap, #mobile-menu, #mobile-menu .sf-menu').removeClass('animate-in');
                    }

				}			

			// open search modal window
			$('ul#icons-menu li.search-icon a').on( 'click' , function(e) {
				e.preventDefault();
				init.openModal('search');
			});

			// open menu modal window
			$('ul#icons-menu li.menu-icon a').on( 'click' , function(e) {
				e.preventDefault();
				init.openModal('menu');
			});

			// close modal window
			$('#search-filter, #search-filter .inner-wrap, #mobile-menu, #mobile-menu .inner-wrap').on( 'click' , function(e) {
		
				// detect if within 'exit' range
				var $target = $(e.target);
				var condition = !$target.closest('.widget-wrap, .sf-menu').length;

				// close modal if condition is met
				if(condition){
					init.closeModal();
				}

			});

		},

		/** Grid Dimension */
		gridDimension: function() {

                var init = {

					/** Item BG Resize */
                	imgResize: function() {

						$('.entry-thumbnail.bg-fit').each(function() {
							$(this).css('background-image', 'url(' + $('img', this).attr('src') + ')');
							$('img', this).hide();
						});

                	},

                	/** Grid Setup */
                    setup: function(){

			            /** Container */
			            var container = $('.grid');

			            for (var i = 0; i < container.length; i++) {

			                /** Container */
			                var containerAct = $(container[i]);
			                var cWidth = containerAct.width();

			                /** Items */
			                var items = containerAct.find('.grid-item');

			                /** Columns */
			                var cols = 1;
			                var attr_cols = parseInt(containerAct.attr('data-col'), 10);

			                /** Margin */
			                var margin = parseInt(containerAct.attr('data-margin'), 10);
			                if (!margin) margin = 0;

			                /** Height */
			                var data_height = parseFloat(containerAct.attr('data-height'));
			                if (!data_height) data_height = 0.7;

			                /** Set margins to the container */
			                container.css({
			                    margin: -Math.floor(margin / 2) + 'px'
			                });

			                if (ww >= 1024) {

			                    cWidth = containerAct.width();
			                    if (attr_cols) cols = attr_cols;
			                    else cols = 3;
			                    
			                    /** Calculating the width and height */
			                    var iWidth = Math.floor((cWidth / cols) - (margin * cols / cols));
			                    var iHeight = Math.floor(iWidth * data_height);
			                    var iMargin = Math.floor(margin / 2);

			                    /** Apply the new width and height **/
			                    items.each(function() {

			                        // console.log(iWidth + ' ' + iHeight + ' ' + iMargin);

			                        $(this).css({
			                            width: iWidth + 'px',
			                            height: iHeight + 'px',
			                            margin: iMargin + 'px'
			                        });

			                        if ( $(this).closest('[data-masonry="true"]').length ) {

			                            // 2x Dimension
			                            if ( $(this).hasClass('height-2x') ) $(this).css('height', (iHeight * 2) + margin + 'px');
			                            if ( $(this).hasClass('width-2x') )  $(this).css('width', (iWidth * 2) + (iMargin * 2) + 'px');

			                            // 3x Dimension
			                            if ( $(this).hasClass('height-3x') ) $(this).css('height', (iHeight * 3) + margin + 'px');
			                            if ( $(this).hasClass('width-3x') )  $(this).css('width', (iWidth * 3) + (iMargin * 4) + 'px');

			                            // 4x Dimension
			                            if ( $(this).hasClass('height-4x') ) $(this).css('height', (iHeight * 4) + margin + 'px');
			                            if ( $(this).hasClass('width-4x') )  $(this).css('width', (iWidth * 4) + (iMargin * 6) + 'px');

			                            // 5x Dimension
			                            if ( $(this).hasClass('height-5x') ) $(this).css('height', (iHeight * 5) + margin + 'px');
			                            if ( $(this).hasClass('width-5x') )  $(this).css('width', (iWidth * 5) + (iMargin * 8) + 'px');

			                            // 6x Dimension
			                            if ( $(this).hasClass('height-6x') ) $(this).css('height', (iHeight * 6) + margin + 'px');
			                            if ( $(this).hasClass('width-6x') )  $(this).css('width', (iWidth * 6) + (iMargin * 10) + 'px');

			                        }

			                    });

			                } else if (ww > 767) {

			                    cWidth = containerAct.width();
			                    if (attr_cols !== 1) cols = 2;

			                    /** Calculating the width and height */
			                    var iWidth = Math.floor((cWidth / cols) - (margin * cols / cols));
			                    var iHeight = Math.floor(iWidth * data_height);
			                    var iMargin = Math.floor(margin / 2);

			                    items.each(function() {
			                        $(this).css({
			                            width: iWidth + 'px',
			                            height: iHeight + 'px',
			                            margin: iMargin + 'px'
			                        });

			                        if ($(this).hasClass('height-2x') && $(this).closest('[data-masonry="true"]').length) $(this).css('height', (iHeight * 2) + margin + 'px');
			                        if ($(this).hasClass('width-2x') && $(this).closest('[data-masonry="true"]').length) $(this).css('width', (iWidth * 2) + (iMargin * 2) + 'px');
			                    });

			                } else {

			                    cWidth = containerAct.width();
			                    cols = cols;

			                    /** Calculating the width and height */
			                    var iWidth = Math.floor((cWidth / cols) - (margin * cols / cols));
			                    var iHeight = Math.floor(iWidth * data_height);
			                    var iMargin = Math.floor(margin / 2);

			                    items.each(function() {
			                        $(this).css({
			                            width: iWidth + 'px',
			                            height: iHeight + 'px',
			                            margin: iMargin + 'px'
			                        });

			                        if ( $(this).closest('[data-masonry="true"]').length ) {

			                            // 2x Dimension
			                            if ( $(this).hasClass('height-2x') ) $(this).css('height', (iHeight * 2) + margin + 'px');
			                            if ( $(this).hasClass('width-2x') )  $(this).css('width', (iWidth * 2) );

			                            // 3x Dimension
			                            if ( $(this).hasClass('height-3x') ) $(this).css('height', (iHeight * 3) + margin + 'px');
			                            if ( $(this).hasClass('width-3x') )  $(this).css('width', (iWidth * 3) );

			                            // 4x Dimension
			                            if ( $(this).hasClass('height-4x') ) $(this).css('height', (iHeight * 4) + margin + 'px');
			                            if ( $(this).hasClass('width-4x') )  $(this).css('width', (iWidth * 4) );

			                            // 5x Dimension
			                            if ( $(this).hasClass('height-5x') ) $(this).css('height', (iHeight * 5) + margin + 'px');
			                            if ( $(this).hasClass('width-5x') )  $(this).css('width', (iWidth * 5) );

			                            // 6x Dimension
			                            if ( $(this).hasClass('height-6x') ) $(this).css('height', (iHeight * 6) + margin + 'px');
			                            if ( $(this).hasClass('width-6x') )  $(this).css('width', (iWidth * 6) );

			                        }
			                    });

			                }

			            }                    	
                    }

				}			

				// execute on DOM ready
				init.setup();
				init.imgResize();

				// re-execute on 'afterInfiniteScroll' triggger
				$('body').on('afterInfiniteScroll', function() {
					init.setup();
					init.imgResize();
				});

		},
		


        /** Isotope Filtering */
        isotopeFiltering: function() {

            var filterLink = $('#portfolio-widget ul.widget-list li a');
            var targetContainer = $('.grid');

            filterLink.on('click', function(e) {
                e.preventDefault();

                filterLink.removeClass('active');
                $(this).addClass('active');
                $('#search-filter, #search-filter .widget-wrap, #mobile-menu, #mobile-menu .sf-menu').removeClass('animate-in');

                var filter = $(this).attr('data-filter');

                targetContainer.isotope({
                    itemSelector: '.grid-item',
                    filter: filter
                });
            });


        },


		/** Sticky Header */
		stickyHeader: function() {

			$('#site-header').headroom({
				offset : 300,
				onUnpin : function() {
					setTimeout(function (){
						$('#site-header').addClass('animate-out');
					}, 400);
				},
				onTop : function() {
					$('#site-header').removeClass('animate-out');
				},
			});

		},

		/** Page Header */
		pageHeader: function() {

			var site_header_h = $('#site-header').outerHeight(true);
			var main_content_m = parseInt( $('#main-content').css('margin-top') );
			var page_header_h = wh - (site_header_h + main_content_m);

			$('#page-header.fullscreen').height(page_header_h)

		},


		/** Flickity Carousel */
		flickityCarousel: function() {

			// init Flickity instance
			var $carousel = $('.main-carousel').flickity({
				cellAlign: 'left',
				contain: true,
				wrapAround: true,
			});


			// configure progress bar
			var time = 8;
			var $bar, $slick, isPause, tick, percentTime;

			$bar = $('.progress-bar .progress');

			$('.main-carousel').on({
				mouseenter: function() {
					isPause = true;
				},
				mouseleave: function() {
					isPause = false;
				}
			})

			function startProgressbar() {
				resetProgressbar();
				percentTime = 0;
				isPause = false;
				tick = setInterval(interval, 10);
			}

			function interval() {
				if(isPause === false) {
					percentTime += 1 / (time+0.1);
					$bar.css({
						width: percentTime+"%"
					});
				if(percentTime >= 100) {
					$carousel.flickity( 'next' )
						startProgressbar();
					}
				}
			}

			function resetProgressbar() {
				$bar.css({
					width: 0+'%' 
				});
				clearTimeout(tick);
			}

			startProgressbar();


			/** reset progress on slide scroll event */
			$carousel.on( 'scroll.flickity', function( event, progress ) {
				startProgressbar();
			});

		},


		/** Packery Layout */
		packeryLayout: function() {

			var $grid = $('.grid');

            var init = {
                setup: function(){
					$grid.packery({
						itemSelector: '.grid-item', 
					});
                },
            }

			// execute on DOM ready
			init.setup();

			// re-execute on 'afterInfiniteScroll' triggger
			$('body').on('afterInfiniteScroll', function(event, items) {
				$grid.packery( 'appended', items );
			});

			// re-execute on 'afterInfiniteScroll' triggger
			$('body').on('resize', function(event) {
				init.setup();
			});

		},

		/** Infinite Scroll */
		infiniteScroll: function() {

            // some checks
			var is_portfolio = $('body').hasClass('page-template-template-portfolio');
			var is_load_more = $('#load-more').length;

			// defining some data (for 'infiniteScroll')
            var $container 	 = is_portfolio ? $('.grid') : $('.blog-minimal');
            var item 		 = is_portfolio ? '.grid-item' : '.type-post';
            var loadMore 	 = '#load-more';
			var load_trigger = $container.data('load-trigger');
			
            // let's start the engines
			var startEngine = {

                init: function(){

					$container.infiniteScroll({
						append: item,
						path: '#load-more a',
						loadOnScroll: (load_trigger == 'button') ? false : true,
						button: loadMore,
						status: '.page-load-status',
						// debug: true,
					});

					// 0: current state of 'infiniteScroll' instance
					var infScroll = $container.data('infiniteScroll');

					// 1: triggers when making request for the next page to be loaded
					$container.on( 'request.infiniteScroll', function( event, path ) {
						if (load_trigger == 'button') {
							$(loadMore).fadeOut(200); // add spinning animation while loading 
						}
					});

					// 2: triggers when next page loaded but not appended
					$container.on( 'load.infiniteScroll', function( event, response, path ) {
						if (load_trigger == 'button') {
							$(loadMore).fadeIn(200); // add spinning animation while loading 
						}
					});

					// 3: triggers after items have been appended to the container
					$container.on( 'append.infiniteScroll', function( event, response, path, items  ) {
						$(items).imagesLoaded( function() {
							$('body').trigger('afterInfiniteScroll', [ items ]);
						});
					});
                },

			}

			// execute on DOM ready
			if (is_load_more) {
				startEngine.init();
			}

		},

		/** Twitter Carousel */
		twitterCarousel: function() {

			// init Flickity instance
			var $carousel = $('.twitter-carousel').flickity({
				cellSelector: '.tweet',
				pageDots: false,
				arrowShape: 'M10.273,5.009c0.444-0.444,1.143-0.444,1.587,0c0.429,0.429,0.429,1.143,0,1.571l-8.047,8.047h26.554  c0.619,0,1.127,0.492,1.127,1.111c0,0.619-0.508,1.127-1.127,1.127H3.813l8.047,8.032c0.429,0.444,0.429,1.159,0,1.587  c-0.444,0.444-1.143,0.444-1.587,0l-9.952-9.952c-0.429-0.429-0.429-1.143,0-1.571L10.273,5.009z'
			});

		},

		/** Site Transitions */
		siteTransitions: function() {

			var $grid = $('.grid');

            var init = {

				/** animate-in whole container */
                animateInContainer: function(){

					$('#site-container').addClass('animate-in');  
					$('#page-header .scroll-indicator').addClass('animate-in');  

                },

				/** animate-in individual items with interval in-between */
                animateInItems: function(items){

					$(items).each(function() {
						setTimeout((function(){
							$(this).addClass('animate-in');
						}).bind(this), $(this).index() * 50 + 100); 
					});

                },

				/** animate on scroll */
                animateOnScroll: function(){

					$(window).on( 'scroll' , function() {
						if ($(window).scrollTop() >= 300) {
							$('#social-share, #page-controls').addClass('animate-in');
						} else {
							$('#social-share, #page-controls').removeClass('animate-in');
						}
					});

                },

				/** make BG passive on scroll */
                makeBgPassive: function(){

					$(window).on( 'scroll' , function() {
						if ($(window).scrollTop() >= 100) {
							$('.hero-header .media').addClass('passive');
							$('#page-header .scroll-indicator').removeClass('animate-in');  
						} else {
							$('.hero-header .media').removeClass('passive');
							$('#page-header .scroll-indicator').addClass('animate-in');  
						}
					});            

                },

				/** animate-in whole container */
                processLocalLinks: function(){

					/** identify all local links */
					$('a:not([href*=#])').filter(function() {
					   return this.hostname && this.hostname === location.hostname;
					}).addClass('local-link');

					/** identify all native link */
					$('#load-more a, ul.widget-list li a').filter(function() {
						$(this).addClass('native-link');
					});

					/** animate-out when a local-link is clicked */
					$('a.local-link').not('a.native-link').on( 'click' , function() {
						$('#site-container').removeClass('animate-in');
						$('.preloader').fadeIn();
					});

                },

            }


			// execute on DOM ready
            init.animateInContainer();
            init.animateInItems('.grid .grid-item');
            // init.animateInItems('.blog-minimal .post, .grid .grid-item');
            init.animateOnScroll();
            init.makeBgPassive();
            init.processLocalLinks();

			// re-execute on 'afterInfiniteScroll' triggger
			$('body').on('afterInfiniteScroll', function(event, items) {

				setTimeout((function(){
					init.animateInItems(items);
				}), 400); 

			});

		},

		/** Elementor Fix */
		elementorFix: function() {

			// progress bar
			$('.elementor-progress-bar').each(function() {
				var leftPos = $(this).data('max');
				$('.elementor-progress-percentage', this).css('left',  leftPos + '%');
			});

			// wp-galery margins
			$('.wp-gallery .image').each(function() {
				var rightMargin = $(this).css('margin-right');
				$(this).css('margin-bottom',  rightMargin);
			});

		},


	}


	/** LOAD */
	/** ================================================== */

	$(window).bind('load', function() {

		/** Load template functions */
		templateFunctions.scrollPosition();
		templateFunctions.siteNotification();
		templateFunctions.sitePreloader();
		templateFunctions.siteMenu();
		templateFunctions.lightBox();
		templateFunctions.siteOverlay();
		templateFunctions.gridDimension();
		templateFunctions.isotopeFiltering();
		templateFunctions.stickyHeader();
		templateFunctions.pageHeader();
		templateFunctions.flickityCarousel();
		templateFunctions.twitterCarousel();
		templateFunctions.packeryLayout();
		templateFunctions.infiniteScroll();
		templateFunctions.siteTransitions();
		templateFunctions.elementorFix();

	});




	/** RESIZE */
	/** ================================================== */

	$(window).bind('resize', function() {

		/** Load template functions */

	});


})( jQuery );