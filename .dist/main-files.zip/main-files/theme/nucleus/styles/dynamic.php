<?php

#-----------------------------------------------------------------#
# Helper Variable(s) and Function(s)
#-----------------------------------------------------------------#


	// Post or Page ID
	if( is_home() || is_archive() || is_search() ) {
		$post_ID = get_option('page_for_posts');
	} else {
		$post_ID = get_the_ID();
	}


	function is_valid_hex_code($colorCode) {
	    // If user accidentally passed along the # sign, strip it off
	    $colorCode = ltrim($colorCode, '#');

	    if (
	          ctype_xdigit($colorCode) &&
	          (strlen($colorCode) == 6 || strlen($colorCode) == 3))
	               return true;

	    else return false;
	}

	// Function to return RGB value if its a color, otherwise return the value as it is
	function get_rgb_value($meta_key) {

		if ( is_valid_hex_code($meta_key) ) {
			$meta_value = implode(", ", hex2rgb($meta_key) ); // If Color
		} else {
			$meta_value = $meta_key; // If Not Color
		}

		return $meta_value;
	}



#-----------------------------------------------------------------#
# General (Tab)
#-----------------------------------------------------------------#

	// Defaults
	$base_colors_default = array(
		'background_color' 	=> '#000',
		'text_color' 		=> '#FFF',
		'link_color' 		=> '#FFF',
		'link_color_hover' 	=> '#FFF',
	);
	$accent_colors_default = array(
		'primary_accent' 	=> '#ffea36',
		'secondary_accent' 	=> '#43f3b7',
	);

	// Meta Panel
	$base_colors 	= get_field('base_colors', $post_ID);
	$accent_colors 	= get_field('accent_colors', $post_ID);

	// Final (merging "Meta Panel + Default")
	$background_color   = isset( $base_colors['background_color'] ) ? get_rgb_value( $base_colors['background_color'] ) : get_rgb_value( $base_colors_default['background_color'] );
	$text_color   		= isset( $base_colors['text_color'] ) ? get_rgb_value( $base_colors['text_color'] ) : get_rgb_value( $base_colors_default['text_color'] );
	$link_color   		= isset( $base_colors['link_color'] ) ? get_rgb_value( $base_colors['link_color'] ) : get_rgb_value( $base_colors_default['link_color'] );
	$link_color_hover   = isset( $base_colors['link_color_hover'] ) ? get_rgb_value( $base_colors['link_color_hover'] ) : get_rgb_value( $base_colors_default['link_color_hover'] );
	
	$primary_accent   	= isset( $accent_colors['primary_accent'] ) ? get_rgb_value( $accent_colors['primary_accent'] ) : get_rgb_value( $accent_colors_default['primary_accent'] );
	$secondary_accent   = isset( $accent_colors['secondary_accent'] ) ? get_rgb_value( $accent_colors['secondary_accent'] ) : get_rgb_value( $accent_colors_default['secondary_accent'] );


#-----------------------------------------------------------------#
# Background Media (Tab)
#-----------------------------------------------------------------#

	// Defaults
	$bg_image_default = array(
		'background_image' 		=> null,
		'background_fit' 		=> 'cover_fit',
	);
	$bg_effects_default = array(
		'background_opacity' 			=> '1',
		'background_blur' 				=> '0',
		'background_opacity_scroll' 	=> '0.8',
		'background_blur_scroll' 		=> '3',
	);

	// Meta Panel
	$bg_image 		= get_field('background_image', $post_ID);
	$bg_effects 	= get_field('background_effects', $post_ID);

	// Final (merging "Meta Panel + Default")
	$background_image   		 = isset( $bg_image['background_image'] ) ? get_rgb_value( $bg_image['background_image'] ) : get_rgb_value( $bg_image_default['background_image'] );
	$background_fit   		 	 = isset( $bg_image['background_fit'] ) ? get_rgb_value( $bg_image['background_fit'] ) : get_rgb_value( $bg_image_default['background_fit'] );
	
	$background_opacity   		 = isset( $bg_effects['background_opacity'] ) ? get_rgb_value( $bg_effects['background_opacity'] ) : get_rgb_value( $bg_effects_default['background_opacity'] );
	$background_blur   		 	 = isset( $bg_effects['background_blur'] ) ? get_rgb_value( $bg_effects['background_blur'] ) : get_rgb_value( $bg_effects_default['background_blur'] );
	$background_opacity_scroll   = isset( $bg_effects['background_opacity_scroll'] ) ? get_rgb_value( $bg_effects['background_opacity_scroll'] ) : get_rgb_value( $bg_effects_default['background_opacity_scroll'] );
	$background_blur_scroll   	 = isset( $bg_effects['background_blur_scroll'] ) ? get_rgb_value( $bg_effects['background_blur_scroll'] ) : get_rgb_value( $bg_effects_default['background_blur_scroll'] );
	

#-----------------------------------------------------------------#
# Menu (Tab)
#-----------------------------------------------------------------#

	// Defaults
	$menu_parent_links_default = array(
		'link_color' 			=> '#FFF',
		'link_color_current' 	=> '#FFF',
		'link_color_hover' 		=> '#FFF',
	);
	$menu_child_wrapper_default = array(
		'background_color' 		=> '#FFF',
		'border_color' 			=> '#FFF',
	);
	$menu_child_links_default = array(
		'link_color' 			=> '#FFF',
		'link_color_current' 	=> '#FFF',
		'link_color_hover' 		=> '#FFF',
	);

	// Meta Panel
	$menu_parent_links 	  = get_field('menu_parent_links', $post_ID);
	$menu_child_wrapper   = get_field('menu_child_wrapper', $post_ID);
	$menu_child_links 	  = get_field('menu_child_links', $post_ID);

	// Final (merging "Meta Panel + Default")
	$menu_parent_link_color   		 			= isset( $menu_parent_links['link_color'] ) ? get_rgb_value( $menu_parent_links['link_color'] ) : get_rgb_value( $menu_parent_links_default['link_color'] );
	$menu_parent_link_color_current   		 	= isset( $menu_parent_links['link_color_current'] ) ? get_rgb_value( $menu_parent_links['link_color_current'] ) : get_rgb_value( $menu_parent_links_default['link_color_current'] );
	$menu_parent_link_color_hover   		 	= isset( $menu_parent_links['link_color_hover'] ) ? get_rgb_value( $menu_parent_links['link_color_hover'] ) : get_rgb_value( $menu_parent_links_default['link_color_hover'] );
	
	$menu_child_wrapper_background_color   		= isset( $menu_child_wrapper['background_color'] ) ? get_rgb_value( $menu_child_wrapper['background_color'] ) : get_rgb_value( $menu_child_wrapper_default['background_color'] );
	$menu_child_wrapper_border_color   			= isset( $menu_child_wrapper['border_color'] ) ? get_rgb_value( $menu_child_wrapper['border_color'] ) : get_rgb_value( $menu_child_wrapper_default['border_color'] );
	
	$menu_child_link_color   		 			= isset( $menu_child_links['link_color'] ) ? get_rgb_value( $menu_child_links['link_color'] ) : get_rgb_value( $menu_child_links_default['link_color'] );
	$menu_child_link_color_current   		 	= isset( $menu_child_links['link_color_current'] ) ? get_rgb_value( $menu_child_links['link_color_current'] ) : get_rgb_value( $menu_child_links_default['link_color_current'] );
	$menu_child_link_color_hover   		 		= isset( $menu_child_links['link_color_hover'] ) ? get_rgb_value( $menu_child_links['link_color_hover'] ) : get_rgb_value( $menu_child_links_default['link_color_hover'] );


#-----------------------------------------------------------------#
# Form (Tab)
#-----------------------------------------------------------------#

	// Defaults
	$form_text_styling_default = array(
		'label_color' 		=> '#838383',
		'req_symbol_color' 	=> '#ff0000',
	);
	$form_field_styling_default = array(
		'background_color' 			=> '#242424',
		'border_color' 				=> '#393939',
		'text_color' 				=> '#B7B7B7',
		'background_color_focus' 	=> '#242424',
		'border_color_focus' 		=> '#555555',
		'text_color_focus' 			=> '#B7B7B7',
	);
	$form_button_styling_default = array(
		'background_color' 			=> '#0FFFBE',
		'border_color' 				=> '#0FFFBE',
		'text_color' 				=> '#000',
		'background_color_hover' 	=> '#EAEAEA',
		'border_color_hover' 		=> '#EAEAEA',
		'text_color_hover' 			=> '#000',
	);

	// Meta Panel
	$form_text_styling 	  = get_field('form_text_styling', $post_ID);
	$form_field_styling   = get_field('form_field_styling', $post_ID);
	$form_button_styling  = get_field('form_button_styling', $post_ID);
	
	// Final (merging "Meta Panel + Default")
	$form_text_label_color   		 	= isset( $form_text_styling['label_color'] ) ? get_rgb_value( $form_text_styling['label_color'] ) : get_rgb_value( $form_text_styling_default['label_color'] );
	$form_text_req_symbol_color   		= isset( $form_text_styling['req_symbol_color'] ) ? get_rgb_value( $form_text_styling['req_symbol_color'] ) : get_rgb_value( $form_text_styling_default['req_symbol_color'] );
		
	$form_field_background_color   		= isset( $form_field_styling['background_color'] ) ? get_rgb_value( $form_field_styling['background_color'] ) : get_rgb_value( $form_field_styling_default['background_color'] );
	$form_field_border_color   		 	= isset( $form_field_styling['border_color'] ) ? get_rgb_value( $form_field_styling['border_color'] ) : get_rgb_value( $form_field_styling_default['border_color'] );
	$form_field_text_color   		 	= isset( $form_field_styling['text_color'] ) ? get_rgb_value( $form_field_styling['text_color'] ) : get_rgb_value( $form_field_styling_default['text_color'] );
	$form_field_background_color_focus  = isset( $form_field_styling['background_color_focus'] ) ? get_rgb_value( $form_field_styling['background_color_focus'] ) : get_rgb_value( $form_field_styling_default['background_color_focus'] );
	$form_field_border_color_focus   	= isset( $form_field_styling['border_color_focus'] ) ? get_rgb_value( $form_field_styling['border_color_focus'] ) : get_rgb_value( $form_field_styling_default['border_color_focus'] );
	$form_field_text_color_focus   		= isset( $form_field_styling['text_color_focus'] ) ? get_rgb_value( $form_field_styling['text_color_focus'] ) : get_rgb_value( $form_field_styling_default['text_color_focus'] );


	$form_button_background_color   	= isset( $form_button_styling['background_color'] ) ? get_rgb_value( $form_button_styling['background_color'] ) : get_rgb_value( $form_button_styling_default['background_color'] );
	$form_button_border_color   		= isset( $form_button_styling['border_color'] ) ? get_rgb_value( $form_button_styling['border_color'] ) : get_rgb_value( $form_button_styling_default['border_color'] );
	$form_button_text_color   		 	= isset( $form_button_styling['text_color'] ) ? get_rgb_value( $form_button_styling['text_color'] ) : get_rgb_value( $form_button_styling_default['text_color'] );
	$form_button_background_color_hover = isset( $form_button_styling['background_color_hover'] ) ? get_rgb_value( $form_button_styling['background_color_hover'] ) : get_rgb_value( $form_button_styling_default['background_color_hover'] );
	$form_button_border_color_hover   	= isset( $form_button_styling['border_color_hover'] ) ? get_rgb_value( $form_button_styling['border_color_hover'] ) : get_rgb_value( $form_button_styling_default['border_color_hover'] );
	$form_button_text_color_hover   	= isset( $form_button_styling['text_color_hover'] ) ? get_rgb_value( $form_button_styling['text_color_hover'] ) : get_rgb_value( $form_button_styling_default['text_color_hover'] );


?>


/** == BACKGROUND MEDIA == */
/** ================================================== */


	/** Background Media */

	<?php if( $background_image ) { ?>

		.hero-header .media {
			background-image: url(<?php echo $background_image; ?>);
		}

	<?php } ?>

	<?php if( $background_fit == "repeat_fit" ) { ?>

		.hero-header .media {
			background-size: auto;
			background-repeat: repeat;
			background-position: left top;
		}

	<?php } else { ?>

		.hero-header .media {
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center center;
		}

	<?php } ?>



	.hero-header .media {
		opacity: <?php echo $background_opacity; ?>;
		filter: blur(<?php echo $background_blur; ?>px);
	}

	.hero-header .media.passive {
		opacity: <?php echo $background_opacity_scroll; ?>;
		filter: blur(<?php echo $background_blur_scroll; ?>px);
	}





/** == COLORS == */
/** ================================================== */


	/** Background Color */
	body,
	.preloader,
	#site-header.headroom--not-top
	{
		background: rgba(<?php echo $background_color; ?>, 1);
	}
	#site-footer::after
	{
		border-color: rgba(<?php echo $background_color; ?>, 1);
	}
	.grid-item .entry-title {
		color: rgba(<?php echo $background_color; ?>, 1);
	}
	.modal-core, #search-filter, #mobile-menu {
		background: rgba(<?php echo $background_color; ?>, 0.95);
	}

	/** Text Color */
	body,
	h1, h2, h3, h4, h5, h6,
	#site-header .logo-wrap #site-logo a,
	#social-share .share-link a,
	#page-controls .page-control,
	ul#main-menu > li > a:hover,
	ul#main-menu > li.sfHover > a,
	ul#main-menu > li.current-menu-item > a,
	ul#main-menu > li.current-menu-parent > a,
	ul#icons-menu li a,
	.scroll-indicator a,
	#page-header .title,
	.single-portfolio .navigation div a,
	#site-footer .title,
	#search-filter .widget-wrap .modal-widget .widget-title.widget-title
	{
		color: rgba(<?php echo $text_color; ?>, 1);
	}


	/** Text Color - Modified */
	ul.sf-menu > li > a,
	#page-header .subtitle,
	#page-header .meta-info,
	#page-header .meta-info a,
	#page-content .page,
	#site-footer .desc,
	#site-footer .social-profiles li a
	{
		color: rgba( <?php echo $text_color; ?>, 0.7 );
	}
	#page-header .meta-info a:hover
	{
		color: rgba( <?php echo $text_color; ?>, 1 );
	}

	#page-header .inner-wrap:before,
	#page-header .inner-wrap:after,
	#site-footer .inner-wrap:before,
	#site-footer .inner-wrap:after
	{
		background: rgba( <?php echo $text_color; ?>, 0.18 ) !important;
	}
	#page-header::after,
	#site-footer::after
	{
		background: rgba( <?php echo $text_color; ?>, 1 ) !important;
	}

	/** Accent Color - Primary */
	#search-filter .widget-wrap .modal-widget ul.widget-list li a
	{
		color: rgba(<?php echo $primary_accent; ?>, 1) !important;
	}
	ul#main-menu > li > a:before,
	ul#main-menu > li.sfHover > a:before
	{
		background-color: rgba(<?php echo $primary_accent; ?>, 1) !important;
	}


	/** Accent Color - Secondary */
	.grid .grid-item .entry-link:hover .entry-caption
	{
		background: rgba(<?php echo $secondary_accent; ?>, 0.9) !important;
	}


/** == FORMS == */
/** ================================================== */


	label {
		color: rgba( <?php echo $form_text_label_color; ?>, 1 ) !important;
	}
	label span.required,
	label ~ span.required
	{
		color: rgba( <?php echo $form_text_req_symbol_color; ?>, 1 ) !important;
	}



	input[type="text"],
	input[type="email"],
	input[type="url"],
	input[type="password"],
	input[type="search"],
	input[type="tel"],
	select,
	textarea {
		color: rgba( <?php echo $form_field_text_color; ?>, 1 ) !important;
		background: rgba( <?php echo $form_field_background_color; ?>, 1 ) !important;
		border: 1px solid rgba( <?php echo $form_field_border_color; ?>, 1 ) !important;
	}
	input[type="text"]:focus,
	input[type="email"]:focus,
	input[type="url"]:focus,
	input[type="password"]:focus,
	input[type="search"]:focus,
	input[type="tel"]:focus,
	select:focus,
	textarea:focus {
		color: rgba( <?php echo $form_field_text_color_focus; ?>, 1 ) !important;
		background: rgba( <?php echo $form_field_background_color_focus; ?>, 1 ) !important;
		border: 1px solid rgba( <?php echo $form_field_border_color_focus; ?>, 1 ) !important;
	}
	#search-filter ::placeholder {
		color: rgba( <?php echo $form_field_text_color; ?>, 0.2 ) !important;
	}


 	.button,
	input[type="submit"],
	button:not(.flickity-prev-next-button):not(.elementor-alert-dismiss),
	input[type="button"] {
		background: rgba( <?php echo $form_button_background_color; ?>, 1 ) !important;
		border-color: rgba( <?php echo $form_button_border_color; ?>, 1 ) !important;
		color: rgba( <?php echo $form_button_text_color; ?>, 1 ) !important;
	}
	input[type="submit"]:hover,
	button:not(.flickity-prev-next-button):hover, .button:hover,
	input[type="button"]:hover {
		background: rgba( <?php echo $form_button_background_color_hover; ?>, 1 ) !important;
		border-color: rgba( <?php echo $form_button_border_color_hover; ?>, 1 ) !important;
		color: rgba( <?php echo $form_button_text_color_hover; ?>, 1 ) !important;
	}