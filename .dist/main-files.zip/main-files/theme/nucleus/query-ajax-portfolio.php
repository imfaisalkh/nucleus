<?php

	// Original Variable(s)
	$portfolio_count 	= get_field('portfolio_count', 2);
	// $portfolio_count 	= get_post_meta( 2, 'portfolio_count', false );
	var_dump( $portfolio_count );

	// Taxonomy Variables
	$taxonomy 			= 'portfolio_category';
	$taxonomy_term_ID 	= get_field($taxonomy);

	$taxonomy_terms = get_terms( $taxonomy, array(
	    'child_of' 	 => $taxonomy_term_ID,
	    'hide_empty' => 0,
	    'fields' 	 => 'ids',
	) );

	array_push($taxonomy_terms, $taxonomy_term_ID); // add parent category to list

	// pagination variable
	$query_vars = json_decode( stripslashes( $_GET['query_vars'] ), true );

	// WP_QUERY Arguments
	$portfolio_args = array(
		'post_type' => $_GET['type'],
		'post_status' => 'publish',
		'tax_query' => array(
			array(
	            'taxonomy' => $taxonomy,
	            'field' => 'id',
	            'terms' => $taxonomy_terms
			),
		),
		'posts_per_page'      => $portfolio_count,
		'paged' 			  => $_GET['page']
	);

	var_dump( $portfolio_args );


	// store query result in variable
	$portfolio_query = new WP_Query( $portfolio_args );

	// loop through query variable
	if ( $portfolio_query->have_posts() ) : while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post();

		get_template_part( 'partials/portfolio/primary-loop' );

	endwhile; endif;