                
            </section>
            <!-- END: SITE BODY -->

            <!-- BEGIN: SITE FOOTER -->
            <footer id="site-footer">

                <?php get_template_part( 'partials/scaffolding/primary-footer' ); ?>

            </footer>
            <!-- END: SITE FOOTER -->

		</main>
		<!-- END: SITE CONTAINER -->

        <?php get_template_part( 'partials/scaffolding/site-controls' ); ?>
        <?php get_template_part( 'partials/scaffolding/site-clipboard' ); ?>


		<!-- WP Footer
		================================================== -->
		<?php wp_footer(); ?>

    </body>

</html>