<?php

    // query arguments
    $blog_args = json_decode( stripslashes( $_GET['query_vars'] ), true );
    $blog_args['paged'] = $_GET['page'];
	$blog_args['orderby'] = 'menu_order';
	$blog_args['order'] = 'ASC';

	// var_dump( $_GET['query_vars'] );

	// store query result in variable
	$blog_query = new WP_Query( $blog_args );

	// loop through query variable
	if ( $blog_query->have_posts() ) : while ( $blog_query->have_posts() ) : $blog_query->the_post();

		get_template_part( 'partials/blog/primary-loop' );

	endwhile; endif;