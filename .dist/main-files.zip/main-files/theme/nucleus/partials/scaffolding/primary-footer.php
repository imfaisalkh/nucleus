<?php
	$footer_title_default = esc_html__( 'Let\'s Talk', 'nucleus');
	$footer_text_default = wp_kses_post( __('Have a Project or an idea you would like to discuss? <br> Then what are you waiting for?', 'nucleus') );
?>

<div class="inner-wrap">
	<h3 class="title"><?php echo get_theme_mod('nucleus_footer_title', $footer_title_default); ?></h3>
	<p class="desc"><?php echo get_theme_mod('nucleus_footer_text', $footer_text_default); ?></p>
	<?php get_template_part( 'partials/scaffolding/social-profiles' ); ?>
</div>