<?php get_header(); ?>

	<!-- Main Content -->
	<div id="main-content">

		<?php get_template_part( 'partials/scaffolding/page-header' ); ?>

		<!-- Page Content -->
		<div id="page-content" class="no-sidebar">

			<?php while( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'partials/single/primary-loop' ); ?>
			<?php endwhile; ?>

			<?php if ( comments_open() || get_comments_number() ) : ?>
				<?php comments_template( '', true ); ?>
			<?php endif; ?>

		</div>

	</div>

<?php get_footer(); ?>