<?php 
/*
Template Name: Portfolio
*/
?>


<?php get_header(); ?>

<?php

	// Original Variable(s)
	$portfolio_layout_config 	= get_field('portfolio_layout_config');
	$portfolio_columns 			= $portfolio_layout_config['columns'];
	$portfolio_gutter 			= $portfolio_layout_config['gutter'];

	$portfolio_entries_config 	= get_field('portfolio_entries_config');
	$portfolio_batch_size 		= $portfolio_entries_config['batch_size'];
	$portfolio_batch_trigger 	= $portfolio_entries_config['batch_trigger'];


	// URL Params Override (for demo purpose)
	$portfolio_columns 	= isset($_GET['columns']) ? $_GET['columns'] : $portfolio_columns;
	$portfolio_gutter 	= isset($_GET['gutter']) ? $_GET['gutter'] : $portfolio_gutter;

	// Taxonomy Variables
	$taxonomy 			= 'portfolio_category';
	$taxonomy_term_ID 	= get_field($taxonomy);

	$taxonomy_terms = get_terms( $taxonomy, array(
	    'child_of' 	 => $taxonomy_term_ID,
	    'hide_empty' => 0,
	    'fields' 	 => 'ids',
	) );

	array_push($taxonomy_terms, $taxonomy_term_ID); // add parent category to list

	// WP_QUERY Arguments
	$portfolio_args = array(
		'post_type' => 'portfolio',
		'tax_query' => array(
			array(
	            'taxonomy' => $taxonomy,
	            'field' => 'id',
	            'terms' => $taxonomy_terms
			),
		),
		'posts_per_page'      => $portfolio_batch_size,
		'paged' 			  => get_query_var( 'page' )
	);


	$portfolio_query = new WP_Query($portfolio_args);

?>

	<div id="main-content">

		<?php get_template_part( 'partials/scaffolding/page-header' ); ?>

		<!-- Page Content -->
		<div id="page-content" class="full-width">

			<?php get_template_part( 'partials/portfolio/featured-slider' ); ?>

			<!-- BEGIN: PORTFOLIO GRID -->
			<section class="grid" data-col="<?php echo esc_attr( $portfolio_columns ); ?>" data-margin="<?php echo esc_attr( $portfolio_gutter ); ?>" data-height="1" data-masonry="true" data-load-trigger="<?php echo esc_attr( $portfolio_batch_trigger ); ?>">

				<?php if ( $portfolio_query->have_posts() ) : while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post(); ?>

					<?php get_template_part( 'partials/portfolio/primary-loop' ); ?> 

				<?php endwhile; else: ?>

					<?php get_template_part( 'content', 'none' ); ?>

				<?php endif; ?>
			  
			</section>
			<!-- END: PORTFOLIO GRID -->

			<?php include(locate_template( 'partials/scaffolding/load-more.php' )); ?>

		</div>

	</div>

<?php get_footer(); ?>