Release Log:

= V1.0 - March, 2021 =

* Initial realease of the theme