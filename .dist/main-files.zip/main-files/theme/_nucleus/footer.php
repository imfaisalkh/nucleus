                    
                </section>
                <!-- END: SITE BODY -->

                <!-- BEGIN: SITE FOOTER -->
                <?php
                   
                ?>

                <footer id="site-footer">
                    <?php get_template_part( 'partials/scaffolding/site-footer' ); ?>
                </footer>
                <!-- END: SITE FOOTER -->

    		</main>
    		<!-- END: SITE CONTAINER -->

            <?php get_template_part( 'partials/scaffolding/site-controls' ); ?>
            <?php get_template_part( 'partials/scaffolding/site-clipboard' ); ?>

        </div>
        <!-- END: ROOT CONTAINER -->

		<!-- WP Footer
		================================================== -->
		<?php wp_footer(); ?>

    </body>

</html>