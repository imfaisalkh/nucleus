<div class="text-block text-block-2 element" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <?php echo get_theme_mod('nucleus_header_text_block_2'); ?>
</div>