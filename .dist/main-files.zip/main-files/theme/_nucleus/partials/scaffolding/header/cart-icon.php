<span class="element cart-icon" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <a href="#" data-tooltip="Purchase Theme"><i class="fi fi-shopping-cart" aria-hidden="true"></i></a>
    <span class="count">0</span>
</span>