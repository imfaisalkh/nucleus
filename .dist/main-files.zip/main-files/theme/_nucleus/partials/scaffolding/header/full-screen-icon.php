<span class="element fullscreen-icon" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <a href="#"><i class="fi fi-fullscreen" aria-hidden="true"></i></a>
</span>