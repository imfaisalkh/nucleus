<span class="search-icon element" data-visibility="<?php echo esc_attr(isset($element['visibility']) ? $element['visibility'] : 'desktop'); ?>">
    <a href="#"><i class="fi fi-search" aria-hidden="true"></i></a>
</span>