                    
                </section>
                <!-- END: SITE BODY -->

    		</main>
    		<!-- END: SITE CONTAINER -->

            <?php get_template_part( 'partials/scaffolding/site-controls' ); ?>
            <?php get_template_part( 'partials/scaffolding/site-clipboard' ); ?>

        </div>
        <!-- END: ROOT CONTAINER -->

		<!-- WP Footer
		================================================== -->
		<?php wp_footer(); ?>

    </body>

</html>